% Simple example how to use unisens in matlab by directly using unisens4java api

% Copyright:
% movisens GmbH, Karlsruhe, Germany
% 
% Author(s): 
% J. Ottenbacher (movisens GmbH)
% 
%  
% Created: 
% 2015-02-20

% import unisens java libraries, not needed if unisens matlab toolbox is installed
javaaddpath(['unisens' filesep 'org.unisens.jar']);
javaaddpath(['unisens' filesep 'org.unisens.ri.jar']);

% path to example data
unisensDataPath='exampleData';

% create unisens object
jUnisensFactory = org.unisens.UnisensFactoryBuilder.createFactory();
jUnisens = jUnisensFactory.createUnisens(unisensDataPath);

% find the ecg entry in the unisens dataset
jEcgEntry = jUnisens.getEntry('ecg.bin');

% get the samplerate
ecgSampleRate=jEcgEntry.getSampleRate();

% use first 10s seconds
ecgCount=10*ecgSampleRate;

% read the whole ecg entry
ecgData = jEcgEntry.readScaled(ecgCount);

% prepare time scale
x = (0:1/ecgSampleRate:(ecgCount-1)/ecgSampleRate);

% plot ecg with title, date, time scale and units
figure
plot(x,ecgData);
title(['ECG measurement: ' char(jUnisens.getMeasurementId()) ', from: ' char(jUnisens.getTimestampStart().toString())]);
xlabel('Time[s]');
ylabel(['ECG [' char(jEcgEntry.getUnit()) ']']);

% close dataset
jUnisens.closeAll();







